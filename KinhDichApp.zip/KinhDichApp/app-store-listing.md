# Hồ sơ App Store — Kinh Dịch: Bói Toán & Kỳ Môn

## Thông tin cơ bản
- **Tên app**: Kinh Dịch — Bói Toán & Kỳ Môn
- **Subtitle**: 64 quẻ · Tử Vi · Kỳ Môn Độn Giáp
- **Bundle ID**: com.kinhdich.app
- **Category chính**: Entertainment (Lifestyle phụ)
- **Age Rating**: 12+ (Infrequent/Mild — nội dung chiêm tinh/tham khảo)
- **Giá**: trả phí một lần (đề xuất $2.99–$4.99) hoặc miễn phí + IAP nâng cấp

## Mô tả (tiếng Việt)
Khám phá trí tuệ cổ đại phương Đông trong một ứng dụng duy nhất:

☯️ KINH DỊCH 64 QUẺ — Ba phép chiêm cổ truyền thống: 3 Đồng Xu, Mai Hoa Dịch Số, Quỷ Cốc Diệu Quyết. Luận giải chi tiết theo Hà Đồ & Lạc Thư: thế ứng, nạp giáp, lục thân, hỗ quẻ, biến quẻ, ứng kỳ.

🧭 KỲ MÔN ĐỘN GIÁP — Lập cục theo giờ chuẩn Thừa Thiên, phương pháp Sướp Bổ: Dương/Âm độn, trực phù trực sử, 12 cát cách, hung cách, luận bệnh tật, 8 lĩnh vực chuyên sâu.

🌟 TỬ VI & BÁT TỰ — An sao đầy đủ, giờ mặt trờI thật theo kinh độ, quy tắc giờ Tý sớm.

🏮 BÁT CUNG DU NIÊN · HÀ LẠC · TAROT — Kết hợp hài hòa Đông – Tây.

✨ Tăng linh nghiệm: nghi lễ tĩnh tâm 3 hơi thở, chỉ dẫn giờ hoàng đạo, nhắc nhở "tái tam độ".

Hoàn toàn OFFLINE — không thu thập dữ liệu.

## Mô tả (English summary)
Authentic Vietnamese I-Ching divination suite: 64 hexagrams (3 traditional casting methods), Qi Men Dun Jia time charts, Zi Wei Dou Shu, Ba Zi with true solar time, Eight Mansions feng shui, Tarot — all offline, no data collection. For cultural reference and entertainment.

## Keywords
kinh dịch, bói toán, quẻ dịch, kỳ môn độn giáp, tử vi, bát tự, i ching, divination, feng shui, tarot

## Privacy Policy URL
Host file `privacy-policy.html` (kèm trong project) lên bất kỳ hosting tĩnh nào (GitHub Pages miễn phí) và dán URL vào App Store Connect.

## App Privacy khai báo trong App Store Connect
- Data collection: **None** (không thu thập dữ liệu nào)
- Tracking: **No**

## Checklist trước khi submit
1. Tài khoản Apple Developer ($99/năm)
2. Điền Team trong Signing & Capabilities
3. Archive (Product → Archive) → Distribute → App Store Connect
4. Upload 3–6 screenshots iPhone 6.7" (chụp từ Simulator iPhone 15 Pro Max)
5. Điền mô tả + keywords + Privacy Policy URL
6. Disclaimer "giải trí/tham khảo" đã có sẵn trong app (card Khuyến Cáo) — reviewer thường yêu cầu, đã đáp ứng
7. Age rating: chọn None cho tất cả nội dung nhạy cảm → 4+ hoặc 12+

## Lưu ý review Apple
- Guideline 5.2.3 / 3.1.1: app bói toán ĐƯỢC phép bán trả phí nếu có disclaimer giải trí.
- Không dùng từ ngữ hứa hẹn "tiên đoán tương lai chính xác" trong mô tả — bản mô tả trên đã tuân thủ.
