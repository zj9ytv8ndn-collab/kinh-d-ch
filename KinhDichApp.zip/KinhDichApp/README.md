# KinhDichApp — Project Xcode cho app Kinh Dịch 64 Quẻ

App iOS native (SwiftUI + WKWebView) bọc toàn bộ hệ thống bói toán
(Kinh Dịch, Tử Vi, Bát Tự, Kỳ Môn Độn Giáp, Bát Cung, Tarot...)
chạy **hoàn toàn offline** — không cần mạng, không server.

## Yêu cầu
- Xcode 15 trở lên (macOS Ventura+)
- iOS 16.0 trở lên

## Cách build
1. Mở `KinhDichApp.xcodeproj` bằng Xcode (double-click).
2. Chọn target **KinhDichApp**, tab **Signing & Capabilities**:
   - Chọn **Team** của bạn (tài khoản Apple ID miễn phí cũng được).
3. Chọn thiết bị: iPhone Simulator (vd. iPhone 15) hoặc iPhone thật.
4. Nhấn **Cmd+R** để chạy.

## Cài lên iPhone thật (miễn phí)
1. Cắm iPhone, chọn nó làm destination.
2. Signing: dùng Personal Team (Apple ID thường).
3. Trên iPhone: Cài đặt → Cài đặt chung → Quản lý VPN & thiết bị
   → Tin cậy developer → mở app.
(App ký miễn phí hết hạn sau 7 ngày; tài khoản Apple Developer
trả phí thì 1 năm / phát hành App Store.)

## Cập nhật nội dung app
Toàn bộ logic nằm trong `KinhDichApp/Resources/index.html`.
Khi có bản web mới, chỉ cần thay file này rồi build lại.

## Cấu trúc
```
KinhDichApp.xcodeproj/      — file project
KinhDichApp/
  KinhDichAppApp.swift      — entry point
  ContentView.swift         — màn hình chính
  WebView.swift             — WKWebView load local HTML
  Resources/index.html      — toàn bộ app (đã kiểm chứng 100%)
```

## Đổi tên / icon
- Tên hiển thị: build setting `CFBundleDisplayName` (hiện "Kinh Dịch").
- Bundle ID: `com.kinhdich.app` — đổi trong Signing & Capabilities.
- Icon: thêm Assets.xcassets với AppIcon 1024×1024 nếu muốn
  (hiện dùng icon mặc định).
